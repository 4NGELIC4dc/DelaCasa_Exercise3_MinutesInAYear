days = 365
hours = 24
minutes = 60
time = (days*hours*minutes)
print("The number of minutes in a year is", time)